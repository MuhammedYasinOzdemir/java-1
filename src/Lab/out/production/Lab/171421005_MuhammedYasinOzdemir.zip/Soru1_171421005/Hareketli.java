package Soru1_171421005;
public interface Hareketli

{
    void yerdegistir(int x,int y);
}
