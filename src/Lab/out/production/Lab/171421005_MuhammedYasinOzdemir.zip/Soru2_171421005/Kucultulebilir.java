package Soru2_171421005;

public interface Kucultulebilir {
    //Muhammed Yasin Özdemir
    //171421005
    double boyutAzalt();
}
